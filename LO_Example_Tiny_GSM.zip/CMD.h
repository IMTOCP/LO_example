#pragma once


char SWITCH_OFF[] = "SWITCH_LIGTH";
