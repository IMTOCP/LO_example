#pragma once


//DEVICE ID ON LO
const char * deviceid = "urn:lo:nsid:heracles_demonstration:exemple";

// YOUR GPRS CREDENTIALS
// Leave empty, if missing user or pass
const char apn[] = "object-connected.fr";
const char user[] = "";
const char pass[] = "";

//BROKER CREDENTIALS
const char* broker = "liveobjects.orange-business.com";
const char LO_MDP[] = "8338715af04f4536a8acc85ae53cae8e"; //IOTSOFTBOX_LB_V1:  
const char LO_USER[] = "json+device";

int PORT = 1883;